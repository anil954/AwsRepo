package com.sathyatel.plandetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.plandetails.dto.PlanDTO;
import com.sathyatel.plandetails.service.impl.PlanServiceImpl;

@RestController
public class PlanRestController {
	
	@Autowired
	PlanServiceImpl service;
	
	@GetMapping(value="/allPlans", produces="application/json")
	public  List<PlanDTO>   getAllPlansByPlanId(String planId) {
		return   service.getAllPlansByPlanId(planId);
				}
	@GetMapping(value="/{planId}",produces="application/json")
	public PlanDTO getSpecificPlan(@PathVariable String planId) //path variable to the paramater of handler
	{
		return service.getSpecificPlan(planId);
	}
}
