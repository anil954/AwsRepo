package com.sathyatel.plandetails.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.plandetails.dto.PlanDTO;
import com.sathyatel.plandetails.entity.Plan;
import com.sathyatel.plandetails.repository.PlanRepository;
import com.sathyatel.plandetails.service.Iplanservice;
@Service
public class PlanServiceImpl implements Iplanservice {
	
	@Autowired
	PlanRepository repository; 
	

	@Override
	public List<PlanDTO> getAllPlansByPlanId(String planId) {
			List<Plan>   list =repository.findAll();
			List<PlanDTO>  list2 = new  ArrayList<PlanDTO>();
			for(Plan  p : list) {
				PlanDTO  dto = new  PlanDTO();
				BeanUtils.copyProperties(p, dto);
				list2.add(dto);
			}
			return   list2;
		
	}

	@Override
	public PlanDTO getSpecificPlan(String planId) {
		
		Optional<Plan>  p = repository.findById(planId);//Returns optional object wrapped plan object through get method
		Plan  pp = p.get();
		PlanDTO  dto = new PlanDTO();//service wants to return dto obj, so we careate a plandto object
		BeanUtils.copyProperties(pp, dto);//copy to plan obj to plandto obj
		return  dto;
	}
}


