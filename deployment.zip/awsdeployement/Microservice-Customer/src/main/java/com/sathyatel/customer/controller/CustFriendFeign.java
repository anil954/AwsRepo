package com.sathyatel.customer.controller;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("FRIENDDETAILSMS")
public interface CustFriendFeign {
	@RequestMapping("/FriendDetailsApi/friends/{phoneNo}")
	public List<Long> getFriendsNumbers(@PathVariable("phoneNo") Long phoneNo);

}
