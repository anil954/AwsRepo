package com.sathyatel.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.model.CustomerDTO;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	@Query(value="select count(*) from customer_details where phone_no=? and password=?", nativeQuery=true)
	Integer verifyUser(Long phoneNo, String password);

}
