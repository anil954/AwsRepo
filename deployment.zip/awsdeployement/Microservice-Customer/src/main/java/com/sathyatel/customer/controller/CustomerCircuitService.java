package com.sathyatel.customer.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.command.AsyncResult;
import com.sathyatel.customer.model.PlanDTO;

//@Service
//public class CustomerCircuitService {
	
	
	/*
	 * @Autowired RestTemplate restTemplate;
	 */	 
	 
	/*
	 * @Autowired CustPlanFeign pfeign;
	 * 
	 * @Autowired CustFriendFeign ffeign;
	 */
	//public static String FRIEND_URL = "http://FRIENDMS/FriendDetailsApi/friends/{phoneNo}";
	//public static String PLAN_URL = "http://PLANDETAILSMS/PlanDetailsApi/{planId}";
	/*@HystrixCommand(fallbackMethod="getFriendsFallback")
	public List<Long> getFriends(Long phoneNo){
		//return restTemplate.getForObject(FRIEND_URL, List.class, phoneNo);
		return ffeign.getFriendsNumbers(phoneNo);
	}
	public Future<PlanDTO> getPlanData(String planId){
		return new AsyncResult<PlanDTO>() {
			public PlanDTO invoke() {
				//return restTemplate.getForObject(PLAN_URL, PlanDTO.class,planId);
				return pfeign.getSpecificPlan(planId);
			}
		};
	}
	public List<Long> getFriendsFallback(Long phoneNo){
		return new ArrayList<Long>();
	}	
}*/
