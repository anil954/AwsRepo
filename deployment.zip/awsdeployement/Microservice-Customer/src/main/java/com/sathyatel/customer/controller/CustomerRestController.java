package com.sathyatel.customer.controller;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.model.CustomerDTO;
import com.sathyatel.customer.model.Login;
import com.sathyatel.customer.model.PlanDTO;
import com.sathyatel.customer.repository.CustomerRepository;
import com.sathyatel.customer.service.ICustomerService;

@RestController
@RibbonClient(name="custribbon")
public class CustomerRestController {
	public static String URL_1 = "http://PLANDETAILSMS/PlanDetailsApi/{planId}";
	public static String URL_2 = "http://FRIENDMS/FriendDetailsApi/friends/{phoneNo}";

	
	 @Autowired 
	 RestTemplate restTemplate;
	@Autowired
	private ICustomerService service;
	@Autowired
	CustomerRepository repo;

	/*
	 * @Autowired CustomerCircuitService circuit;
	 */	
	@PostMapping("/register")
	public    String    registerCustomer(@RequestBody   Customer  customer) {

		boolean flag=service.addCustomer(customer);
		{ if(flag==true) { return
				"Customer registered sccessfully"; 
		}else { 
			return "Customer already exists";
		}
		} 
	}


	@PostMapping("/login")
	public    boolean    verifyLogin(@RequestBody  Login   login) {
		return    service.checkLogin(login);
	}
	@GetMapping("/viewProfile/{phoneNo}")
	public CustomerDTO getCustomerProfile(@PathVariable Long phoneNo) {
		System.out.println("from Customer");
			CustomerDTO customerDto=service.getCustomerDetails(phoneNo);
			PlanDTO planDto = restTemplate.getForObject(URL_1,PlanDTO.class,customerDto.getPlanId());
			customerDto.setCurrentPLan(planDto);
			List friendsNo=restTemplate.getForObject(URL_2,List.class,customerDto.getPhoneNo());
			customerDto.setFriends(friendsNo);
			customerDto.setCurrentPLan(planDto);
			return customerDto;

	}

	
	/*public CustomerDTO getCustomerProfile(@PathVariable Long phoneNo) {
		long x = System.currentTimeMillis();
		CustomerDTO customerDto=service.getCustomerDetails(phoneNo);
		PlanDTO planDto = restTemplate.getForObject(URL_1,PlanDTO.class,customerDto.getPlanId());
		  customerDto.setCurrentPLan(planDto);
	*/	 
		/*
		 * Future<PlanDTO> future = circuit.getPlanData(customerDto.getPlanId()); try {
		 * customerDto.setCurrentPLan(future.get());
		 * 
		 * }catch(Exception e) {}
		 */
		  
		
		  /*List friendsNo=restTemplate.getForObject(URL_2,List.class,customerDto.getPhoneNo()); 
		  customerDto.setFriends(friendsNo); customerDto.setCurrentPLan(planDto);
		  return customerDto;
	*/
		/*
		 * List<Long> friendsContactNumbers = circuit.getFriends(phoneNo);
		 * customerDto.setFriends(friendsContactNumbers); long y =
		 * System.currentTimeMillis();
		 * System.out.println("Time taking in millis: "+(y-x));
		 */		 
	}
