package com.sathyatel.customer.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.model.CustomerDTO;
import com.sathyatel.customer.model.Login;
import com.sathyatel.customer.repository.CustomerRepository;
import com.sathyatel.customer.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	CustomerRepository repo;

	@Override
	public boolean addCustomer(Customer customer) {
		boolean flag=repo.existsById(customer.getPhoneNo());
		if(flag==false)
		{
		repo.saveAndFlush(customer);
		return true ;
	}
		else {
			return false;
		}
	}

	@Override
	public   boolean  checkLogin(Login  login) {
		Integer count=repo.verifyUser(login.getPhoneNo(),login.getPassword());
		if(count==1) {
			/*
			 * Optional<Customer> opt=repo.findById(login.getPhoneNo()); Customer
			 * customer=opt.get();
			 */
				return  true;
			}
			else {
				return  false;
			}
		}
		
	
	public  CustomerDTO   getCustomerDetails(Long  phoneNo) {
		Optional<Customer>  opt = repo.findById(phoneNo);
		Customer  customer =opt.get();
		CustomerDTO  dto =new  CustomerDTO();
		/*dto.setPhoneNo(customer.getPhoneNo());
		dto.setName(customer.getName());
		dto.setAge(customer.getAge());
		dto.setPlanId(customer.getPlanId());*/
		BeanUtils.copyProperties(customer, dto);
		return dto;
	}
}
