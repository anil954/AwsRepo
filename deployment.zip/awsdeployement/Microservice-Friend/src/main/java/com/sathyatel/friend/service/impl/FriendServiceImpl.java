package com.sathyatel.friend.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.friend.entity.Friend;
import com.sathyatel.friend.repository.FriendRepository;
import com.sathyatel.friend.service.IFriendService;
@Service
public class FriendServiceImpl implements IFriendService {
	@Autowired
	FriendRepository repo;

	@Override
	public String addFriendService(Friend friend) {
		Integer count = repo.verifyFriendNo(friend.getPhoneNo(), friend.getFriendNo());
		System.out.println(friend);
		if(count==0) {
			repo.save(friend);
			return "Friend contact is added";
		}
		else {
			return "Friend contact already exist";
		}
	
	}

	@Override
	public List<Long> getFriendsListService(Long phoneNo) {
		List<Friend> friendList = repo.findByPhoneNo(phoneNo);
		List<Long> friendsContactList = new ArrayList();
		
		for(Friend friend: friendList) {
			friendsContactList.add(friend.getFriendNo());
			
		}
		return friendsContactList;
	}

}
